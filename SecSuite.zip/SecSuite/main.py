"""
╔══════════════════════════════════════════════════════════╗
║              SECSUITE — Defensive Security Suite         ║
║              Entry point — run this file                 ║
╚══════════════════════════════════════════════════════════╝

Usage:
    python main.py

Requirements:
    pip install customtkinter
"""

from app import App

if __name__ == "__main__":
    app = App()
    app.mainloop()
