"""
utils/widgets.py — Shared reusable widgets used across all modules.

    Terminal   — dark scrollable log output box with colour tags
    StatsBar   — horizontal row of metric cards (label + big number)
    make_btn   — quick helper that returns a styled CTkButton
"""

import tkinter as tk
import customtkinter as ctk
from datetime import datetime
from utils.theme import COLORS, FONT_MONO, FONT_LABEL, FONT_HEAD


# ─────────────────────────────────────────────────────────────────────────────
class Terminal(tk.Text):
    """
    Terminal-style dark log widget.

    Severity tags:
        info    blue
        ok      green
        warn    amber
        danger  red
        muted   grey
        header  purple
    """

    TAG_COLORS = {
        "info":   "#60a5fa",
        "ok":     "#22c55e",
        "warn":   "#f59e0b",
        "danger": "#ef4444",
        "muted":  "#6b7280",
        "header": "#c084fc",
    }

    def __init__(self, master, **kw):
        defaults = dict(
            bg="#0d1117",
            fg="#e2e8f0",
            insertbackground="#e2e8f0",
            font=FONT_MONO,
            wrap="word",
            state="disabled",
            relief="flat",
            bd=0,
            padx=10,
            pady=10,
        )
        defaults.update(kw)
        super().__init__(master, **defaults)
        for tag, color in self.TAG_COLORS.items():
            self.tag_config(tag, foreground=color)

    def log(self, msg: str, tag: str = ""):
        """Append a timestamped line with optional colour tag."""
        self.configure(state="normal")
        ts = datetime.now().strftime("%H:%M:%S")
        self.insert("end", f"[{ts}] {msg}\n", tag)
        self.see("end")
        self.configure(state="disabled")

    def clear(self):
        """Wipe all content."""
        self.configure(state="normal")
        self.delete("1.0", "end")
        self.configure(state="disabled")


# ─────────────────────────────────────────────────────────────────────────────
class StatsBar(ctk.CTkFrame):
    """
    Horizontal row of metric cards.

    Usage:
        bar = StatsBar(parent, labels=["Open ports", "Risky", "Closed"])
        bar.pack(fill="x")
        bar.set("Open ports", "12")
    """

    def __init__(self, master, labels: list[str], **kw):
        kw.setdefault("fg_color", COLORS["card"])
        kw.setdefault("corner_radius", 10)
        super().__init__(master, **kw)
        self._vars: dict[str, tk.StringVar] = {}
        for label in labels:
            v = tk.StringVar(value="—")
            self._vars[label] = v
            col = ctk.CTkFrame(self, fg_color="transparent")
            col.pack(side="left", expand=True, padx=20, pady=12)
            ctk.CTkLabel(col, textvariable=v,
                         font=("Segoe UI", 22, "bold"),
                         text_color=COLORS["text"]).pack()
            ctk.CTkLabel(col, text=label,
                         font=("Segoe UI", 11),
                         text_color=COLORS["muted"]).pack()

    def set(self, label: str, value: str):
        """Update a stat value by its label string."""
        if label in self._vars:
            self._vars[label].set(value)

    def reset(self):
        """Reset all stats to —."""
        for v in self._vars.values():
            v.set("—")


# ─────────────────────────────────────────────────────────────────────────────
def make_btn(master, text: str, color: str = "accent",
             width: int = 100, **kw) -> ctk.CTkButton:
    """
    Convenience factory for consistently styled buttons.

    color can be any key in COLORS or a raw hex string.
    """
    fg = COLORS.get(color, color)
    return ctk.CTkButton(master, text=text, width=width,
                         fg_color=fg, font=FONT_LABEL, **kw)
