"""
utils/reporter.py — Save module results to plain-text report files.

Usage:
    from utils.reporter import Reporter
    r = Reporter("Port Scan")
    r.add("OPEN  22  SSH")
    r.add("OPEN  80  HTTP")
    path = r.save()          # returns the saved file path
"""

import os
from datetime import datetime
from utils.config import get


class Reporter:
    """Accumulates log lines and writes them to a timestamped report file."""

    def __init__(self, title: str) -> None:
        self._title  = title
        self._lines: list[str] = []
        self._started = datetime.now()

    def add(self, line: str) -> None:
        """Append a line to the report (no timestamp added)."""
        self._lines.append(line)

    def add_ts(self, line: str) -> None:
        """Append a line prefixed with the current time."""
        ts = datetime.now().strftime("%H:%M:%S")
        self._lines.append(f"[{ts}] {line}")

    def save(self) -> str:
        """
        Write the report to disk and return the full file path.
        Output directory is taken from config → reports.output_dir.
        """
        out_dir = get("reports", "output_dir")
        os.makedirs(out_dir, exist_ok=True)

        stamp    = self._started.strftime("%Y%m%d_%H%M%S")
        safe     = self._title.lower().replace(" ", "_")
        filename = f"{safe}_{stamp}.txt"
        path     = os.path.join(out_dir, filename)

        header = (
            f"{'=' * 60}\n"
            f"  SecSuite — {self._title}\n"
            f"  Generated : {self._started.strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"{'=' * 60}\n\n"
        )
        footer = (
            f"\n{'=' * 60}\n"
            f"  End of report  •  {len(self._lines)} lines\n"
            f"{'=' * 60}\n"
        )

        with open(path, "w", encoding="utf-8") as f:
            f.write(header)
            f.write("\n".join(self._lines))
            f.write(footer)

        return path
