"""
utils/theme.py — Colour palette, fonts, and shared style constants.
Import this in every module to keep the UI consistent.
"""

COLORS = {
    "bg":       "#0f1117",
    "panel":    "#1a1d27",
    "card":     "#21253a",
    "accent":   "#3b82f6",
    "success":  "#22c55e",
    "warning":  "#f59e0b",
    "danger":   "#ef4444",
    "muted":    "#6b7280",
    "text":     "#e2e8f0",
    "border":   "#2d3148",
}

FONT_MONO  = ("Courier New", 11)
FONT_LABEL = ("Segoe UI",    12)
FONT_HEAD  = ("Segoe UI",    14, "bold")
FONT_TITLE = ("Segoe UI",    20, "bold")
FONT_SMALL = ("Segoe UI",    10)
