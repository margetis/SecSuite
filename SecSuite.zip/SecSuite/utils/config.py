"""
utils/config.py — Load and access app configuration from config.json.
Falls back to sensible defaults if the file is missing or malformed.
"""

import json
import os
from typing import Any

_DEFAULTS: dict = {
    "port_scanner":    {"default_host": "127.0.0.1", "default_port_from": 1,
                        "default_port_to": 1024, "default_timeout": 0.5},
    "brute_force":     {"default_threshold": 5, "default_window_s": 60},
    "file_integrity":  {"watch_interval_s": 15, "baseline_file": "fim_baseline.json"},
    "reports":         {"output_dir": "reports"},
}

_CONFIG_PATH = os.path.join(os.path.dirname(__file__), "..", "config.json")
_data: dict = {}


def _load() -> None:
    global _data
    try:
        with open(_CONFIG_PATH) as f:
            _data = json.load(f)
    except (OSError, json.JSONDecodeError):
        _data = {}


def get(section: str, key: str) -> Any:
    """Return config value, falling back to built-in default."""
    if not _data:
        _load()
    return _data.get(section, {}).get(key, _DEFAULTS.get(section, {}).get(key))


_load()
