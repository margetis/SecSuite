"""
app.py — Main application window, sidebar navigation, and tab container.
"""

import customtkinter as ctk
import tkinter as tk

from utils.theme import COLORS, FONT_LABEL

from modules.dashboard      import Dashboard
from modules.log_analyser   import LogAnalyser
from modules.port_scanner   import PortScanner
from modules.brute_force    import BruteForceDetector
from modules.file_integrity import FileIntegrityMonitor
from modules.settings       import Settings

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

VERSION = "1.0.0"


class App(ctk.CTk):
    def __init__(self) -> None:
        super().__init__()
        self.title("SecSuite — Defensive Security Suite")
        self.geometry("1020x800")
        self.minsize(860, 640)
        self.configure(fg_color=COLORS["bg"])
        self._build()

    def _build(self) -> None:
        # ── Sidebar ───────────────────────────────────────────────────────────
        sidebar = ctk.CTkFrame(self, width=210, fg_color=COLORS["panel"],
                               corner_radius=0)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        logo_frame = ctk.CTkFrame(sidebar, fg_color=COLORS["card"], corner_radius=12)
        logo_frame.pack(fill="x", padx=12, pady=(20, 4))
        ctk.CTkLabel(logo_frame, text="🛡", font=("Segoe UI", 30)).pack(pady=(12, 0))
        ctk.CTkLabel(logo_frame, text="SecSuite",
                     font=("Segoe UI", 17, "bold"),
                     text_color=COLORS["accent"]).pack()
        ctk.CTkLabel(logo_frame, text=f"v{VERSION}  •  Defensive Tools",
                     font=("Segoe UI", 9),
                     text_color=COLORS["muted"]).pack(pady=(0, 12))

        ctk.CTkLabel(sidebar, text="  NAVIGATE",
                     font=("Segoe UI", 9, "bold"),
                     text_color=COLORS["muted"]).pack(anchor="w", padx=16, pady=(14, 4))

        self._tabs: dict[str, ctk.CTkFrame] = {}
        self._btns: dict[str, ctk.CTkButton] = {}

        nav_items = [
            ("home",  "🏠", "Dashboard"),
            ("log",   "📋", "Log Analyser"),
            ("port",  "🔍", "Port Scanner"),
            ("brute", "🛡", "Brute-Force"),
            ("fim",   "🔒", "File Integrity"),
        ]
        for key, icon, label in nav_items:
            btn = ctk.CTkButton(
                sidebar,
                text=f"  {icon}  {label}",
                anchor="w", height=44,
                fg_color="transparent",
                hover_color=COLORS["card"],
                text_color=COLORS["text"],
                font=("Segoe UI", 13),
                corner_radius=8,
                command=lambda k=key: self._show(k),
            )
            btn.pack(fill="x", padx=10, pady=2)
            self._btns[key] = btn

        # Settings at bottom
        ctk.CTkFrame(sidebar, fg_color=COLORS["border"], height=1).pack(
            fill="x", padx=16, pady=12)
        settings_btn = ctk.CTkButton(
            sidebar,
            text="  ⚙  Settings",
            anchor="w", height=40,
            fg_color="transparent",
            hover_color=COLORS["card"],
            text_color=COLORS["muted"],
            font=("Segoe UI", 12),
            corner_radius=8,
            command=lambda: self._show("settings"),
        )
        settings_btn.pack(fill="x", padx=10)
        self._btns["settings"] = settings_btn

        ctk.CTkLabel(sidebar,
            text="Only scan systems\nyou own or have\npermission to test.",
            font=("Segoe UI", 9), text_color=COLORS["muted"],
            justify="left",
        ).pack(side="bottom", anchor="w", padx=16, pady=16)

        # ── Content ───────────────────────────────────────────────────────────
        self._content = ctk.CTkFrame(self, fg_color=COLORS["bg"], corner_radius=0)
        self._content.pack(side="left", fill="both", expand=True, padx=24, pady=24)

        # Dashboard is built first so other modules can hold a reference to it
        dash = Dashboard(self._content, switch_tab_cb=self._show)
        log  = LogAnalyser(self._content,        dashboard=dash)
        port = PortScanner(self._content,         dashboard=dash)
        brut = BruteForceDetector(self._content,  dashboard=dash)
        fim  = FileIntegrityMonitor(self._content,dashboard=dash)
        sett = Settings(self._content)

        modules = {
            "home": dash, "log": log, "port": port,
            "brute": brut, "fim": fim, "settings": sett,
        }
        self._tabs = modules
        for frame in modules.values():
            frame.place(relx=0, rely=0, relwidth=1, relheight=1)

        self._show("home")

    def _show(self, key: str) -> None:
        for k, frame in self._tabs.items():
            frame.lower() if k != key else frame.lift()
        for k, btn in self._btns.items():
            is_active = k == key
            btn.configure(
                fg_color=COLORS["accent"] if is_active else "transparent",
                text_color="#ffffff"       if is_active else (
                    COLORS["muted"] if k == "settings" else COLORS["text"]
                ),
                font=("Segoe UI", 13, "bold") if is_active else ("Segoe UI", 13),
            )
