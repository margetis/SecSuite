"""
modules/settings.py — Settings panel for configuring defaults.

Reads from and writes back to config.json so changes persist across sessions.
"""

import json
import os
import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox

from utils.theme  import COLORS, FONT_LABEL, FONT_TITLE, FONT_HEAD, FONT_SMALL

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "..", "config.json")


def _load_raw() -> dict:
    try:
        with open(CONFIG_PATH) as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}


def _save_raw(data: dict) -> None:
    with open(CONFIG_PATH, "w") as f:
        json.dump(data, f, indent=2)


class Settings(ctk.CTkFrame):
    def __init__(self, master) -> None:
        super().__init__(master, fg_color="transparent")
        self._fields: dict[str, tk.StringVar] = {}
        self._build()

    # ── Layout ────────────────────────────────────────────────────────────────
    def _build(self) -> None:
        ctk.CTkLabel(self, text="⚙  Settings", font=FONT_TITLE,
                     text_color=COLORS["accent"]).pack(anchor="w", pady=(0, 4))
        ctk.CTkLabel(self,
            text="These defaults are saved to config.json and loaded every time "
                 "the app starts.",
            font=FONT_LABEL, text_color=COLORS["muted"],
        ).pack(anchor="w", pady=(0, 18))

        cfg = _load_raw()

        sections = [
            ("Port Scanner", "port_scanner", [
                ("Default host",        "default_host",     "127.0.0.1"),
                ("Default port — from", "default_port_from","1"),
                ("Default port — to",   "default_port_to",  "1024"),
                ("Default timeout (s)", "default_timeout",  "0.5"),
            ]),
            ("Brute-Force Detector", "brute_force", [
                ("Max attempts before block", "default_threshold", "5"),
                ("Time window (s)",           "default_window_s",  "60"),
            ]),
            ("File Integrity Monitor", "file_integrity", [
                ("Watch interval (s)", "watch_interval_s", "15"),
                ("Baseline file name", "baseline_file",    "fim_baseline.json"),
            ]),
            ("Reports", "reports", [
                ("Output directory", "output_dir", "reports"),
            ]),
        ]

        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True, pady=(0, 12))

        for section_title, section_key, fields in sections:
            sec = ctk.CTkFrame(scroll, fg_color=COLORS["card"], corner_radius=12)
            sec.pack(fill="x", pady=(0, 12))

            ctk.CTkLabel(sec, text=section_title,
                         font=FONT_HEAD, text_color=COLORS["text"],
                         ).pack(anchor="w", padx=16, pady=(12, 8))

            for label, key, default in fields:
                row = ctk.CTkFrame(sec, fg_color="transparent")
                row.pack(fill="x", padx=16, pady=3)
                ctk.CTkLabel(row, text=label, font=FONT_LABEL,
                             width=220, anchor="w").pack(side="left")
                val = str(cfg.get(section_key, {}).get(key, default))
                v = tk.StringVar(value=val)
                self._fields[f"{section_key}.{key}"] = v
                ctk.CTkEntry(row, textvariable=v, width=220).pack(side="left", padx=8)

            ctk.CTkFrame(sec, fg_color="transparent", height=8).pack()

        # Save button
        btn_row = ctk.CTkFrame(self, fg_color="transparent")
        btn_row.pack(anchor="e")
        ctk.CTkButton(btn_row, text="Save Settings", width=140,
                      fg_color=COLORS["success"],
                      font=FONT_LABEL,
                      command=self._save).pack(side="right")
        ctk.CTkButton(btn_row, text="Reset to Defaults", width=150,
                      fg_color=COLORS["card"],
                      font=FONT_LABEL,
                      command=self._reset).pack(side="right", padx=(0, 8))

    # ── Logic ─────────────────────────────────────────────────────────────────
    def _save(self) -> None:
        cfg = _load_raw()
        for dotkey, var in self._fields.items():
            section, key = dotkey.split(".", 1)
            cfg.setdefault(section, {})[key] = var.get()
        _save_raw(cfg)
        messagebox.showinfo("Saved", "Settings saved to config.json.\n"
                            "Restart the app for all changes to take effect.")

    def _reset(self) -> None:
        defaults = {
            "port_scanner.default_host":     "127.0.0.1",
            "port_scanner.default_port_from":"1",
            "port_scanner.default_port_to":  "1024",
            "port_scanner.default_timeout":  "0.5",
            "brute_force.default_threshold": "5",
            "brute_force.default_window_s":  "60",
            "file_integrity.watch_interval_s":"15",
            "file_integrity.baseline_file":  "fim_baseline.json",
            "reports.output_dir":            "reports",
        }
        for k, v in defaults.items():
            if k in self._fields:
                self._fields[k].set(v)
