"""
modules/brute_force.py — Login brute-force detector.

Tracks failed login attempts per IP address within a rolling time window.
When an IP exceeds the threshold it is added to the blocked list.

Public API:
    record_attempt(ip, success=False) — feed in a login event
"""

import time
import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox

from utils.theme    import COLORS, FONT_LABEL, FONT_TITLE, FONT_HEAD, FONT_MONO
from utils.widgets  import Terminal, make_btn
from utils.config   import get
from utils.reporter import Reporter


class BruteForceDetector(ctk.CTkFrame):
    def __init__(self, master, dashboard=None) -> None:
        super().__init__(master, fg_color="transparent")
        self._attempts: dict[str, list[float]] = {}
        self._blocked:  set[str] = set()
        self._dashboard = dashboard
        self._reporter  = Reporter("Brute-Force Detection")
        self._build()

    def _build(self) -> None:
        ctk.CTkLabel(self, text="🛡  Brute-Force Detector", font=FONT_TITLE,
                     text_color=COLORS["accent"]).pack(anchor="w", pady=(0, 4))
        ctk.CTkLabel(self,
            text="Tracks failed login attempts per IP in a rolling time window. "
                 "IPs that exceed the threshold are automatically blocked.",
            font=FONT_LABEL, text_color=COLORS["muted"], wraplength=740,
        ).pack(anchor="w", pady=(0, 12))

        cfg = ctk.CTkFrame(self, fg_color="transparent")
        cfg.pack(fill="x", pady=(0, 6))

        def lbl(t: str) -> ctk.CTkLabel:
            return ctk.CTkLabel(cfg, text=t, font=FONT_LABEL)

        lbl("Max attempts before block:").pack(side="left", padx=(0, 6))
        self._threshold = tk.StringVar(value=str(get("brute_force", "default_threshold")))
        ctk.CTkEntry(cfg, textvariable=self._threshold, width=55).pack(side="left", padx=4)

        lbl("Time window (s):").pack(side="left", padx=(16, 6))
        self._window = tk.StringVar(value=str(get("brute_force", "default_window_s")))
        ctk.CTkEntry(cfg, textvariable=self._window, width=65).pack(side="left", padx=4)

        sim = ctk.CTkFrame(self, fg_color="transparent")
        sim.pack(fill="x", pady=(4, 8))
        ctk.CTkLabel(sim, text="Simulate IP:", font=FONT_LABEL).pack(side="left", padx=(0, 6))
        self._sim_ip = tk.StringVar(value="192.168.1.42")
        ctk.CTkEntry(sim, textvariable=self._sim_ip, width=150).pack(side="left", padx=4)
        make_btn(sim, "1 attempt",       "card",    width=110,
                 command=lambda: self._simulate(1, False)).pack(side="left", padx=3)
        make_btn(sim, "Burst ×10",       "warning", width=100,
                 command=lambda: self._simulate(10, False)).pack(side="left", padx=3)
        make_btn(sim, "Successful login","success", width=130,
                 command=lambda: self._simulate(1, True)).pack(side="left", padx=3)
        make_btn(sim, "Export",          "card",    width=80,
                 command=self._export).pack(side="left", padx=3)
        make_btn(sim, "Reset",           "card",    width=80,
                 command=self._reset).pack(side="left", padx=3)

        blocked_card = ctk.CTkFrame(self, fg_color=COLORS["card"], corner_radius=10)
        blocked_card.pack(fill="x", pady=(0, 10))
        ctk.CTkLabel(blocked_card, text="🚫  Blocked IPs",
                     font=FONT_HEAD, text_color=COLORS["danger"],
                     ).pack(anchor="w", padx=16, pady=(10, 2))
        self._blocked_label = ctk.CTkLabel(
            blocked_card, text="None", font=FONT_MONO,
            text_color=COLORS["muted"],
        )
        self._blocked_label.pack(anchor="w", padx=16, pady=(0, 10))

        self._term = Terminal(self)
        self._term.pack(fill="both", expand=True)

    # ── Public API ────────────────────────────────────────────────────────────
    def record_attempt(self, ip: str, success: bool = False) -> None:
        """Register one login event. Call with success=True on a valid login."""
        ip        = ip.strip()
        threshold = int(self._threshold.get())
        window    = float(self._window.get())
        now       = time.time()

        if ip in self._blocked:
            msg = f"Blocked IP {ip} attempted another login."
            self._term.log(msg, "danger")
            self._reporter.add_ts(msg)
            return

        if success:
            msg = f"Successful login from {ip}."
            self._term.log(msg, "ok")
            self._reporter.add_ts(msg)
            self._attempts.pop(ip, None)
            return

        self._attempts.setdefault(ip, [])
        self._attempts[ip].append(now)
        self._attempts[ip] = [t for t in self._attempts[ip] if now - t <= window]
        count = len(self._attempts[ip])

        if count >= threshold:
            self._blocked.add(ip)
            msg = f"BLOCKED {ip} — {count} failed attempts within {window}s"
            self._term.log(f"🚨  {msg}", "danger")
            self._reporter.add_ts(f"[BLOCK] {msg}")
            self._refresh_blocked()
            if self._dashboard:
                self._dashboard.increment("ips_blocked")
        else:
            severity = "warn" if count >= max(threshold // 2, 1) else "info"
            msg = f"Failed login from {ip}  ({count}/{threshold} in window)"
            self._term.log(msg, severity)
            self._reporter.add_ts(msg)

    # ── Internal ──────────────────────────────────────────────────────────────
    def _simulate(self, n: int, success: bool) -> None:
        for _ in range(n):
            self.record_attempt(self._sim_ip.get(), success=success)

    def _reset(self) -> None:
        self._attempts.clear()
        self._blocked.clear()
        self._refresh_blocked()
        self._term.clear()
        self._reporter = Reporter("Brute-Force Detection")
        self._term.log("State reset. All counters and blocks cleared.", "muted")

    def _refresh_blocked(self) -> None:
        if self._blocked:
            self._blocked_label.configure(
                text="   ".join(sorted(self._blocked)),
                text_color=COLORS["danger"],
            )
        else:
            self._blocked_label.configure(text="None", text_color=COLORS["muted"])

    def _export(self) -> None:
        path = self._reporter.save()
        messagebox.showinfo("Report saved", f"Saved to:\n{path}")
