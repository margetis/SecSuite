"""
modules/file_integrity.py — SHA-256 file integrity monitor.

Workflow:
    1. Pick a directory.
    2. Create Baseline → hashes every file → saves to fim_baseline.json
    3. Check Now or Start Watch → reports changes, deletions, new files.
"""

import os
import json
import time
import hashlib
import threading
from tkinter import filedialog, messagebox
import customtkinter as ctk
import tkinter as tk

from utils.theme    import COLORS, FONT_LABEL, FONT_TITLE
from utils.widgets  import Terminal, StatsBar, make_btn
from utils.config   import get
from utils.reporter import Reporter


class FileIntegrityMonitor(ctk.CTkFrame):
    def __init__(self, master, dashboard=None) -> None:
        super().__init__(master, fg_color="transparent")
        self._watch_dir: str | None = None
        self._baseline:  dict[str, str] = {}
        self._watching   = False
        self._dashboard  = dashboard
        self._reporter: Reporter | None = None
        self._baseline_file = str(get("file_integrity", "baseline_file"))
        self._interval      = int(get("file_integrity", "watch_interval_s"))
        self._build()

    def _build(self) -> None:
        ctk.CTkLabel(self, text="🔒  File Integrity Monitor", font=FONT_TITLE,
                     text_color=COLORS["accent"]).pack(anchor="w", pady=(0, 4))
        ctk.CTkLabel(self,
            text="Build a SHA-256 baseline for a directory, then monitor it for "
                 "changes, additions, or deletions.",
            font=FONT_LABEL, text_color=COLORS["muted"], wraplength=740,
        ).pack(anchor="w", pady=(0, 12))

        row = ctk.CTkFrame(self, fg_color="transparent")
        row.pack(fill="x", pady=(0, 8))
        self._dir_var = tk.StringVar(value="No directory selected")
        ctk.CTkLabel(row, textvariable=self._dir_var,
                     font=FONT_LABEL, text_color=COLORS["muted"]).pack(side="left", padx=(0, 10))
        make_btn(row, "Browse…",         "card",    command=self._browse).pack(side="left", padx=2)
        make_btn(row, "Create Baseline", "success", width=140,
                 command=self._start_baseline).pack(side="left", padx=2)
        self._watch_btn = make_btn(row, "Start Watch", "accent", width=120,
                                   command=self._toggle_watch)
        self._watch_btn.pack(side="left", padx=2)
        make_btn(row, "Check Now", "card", width=110,
                 command=lambda: threading.Thread(
                     target=self._check, daemon=True).start()).pack(side="left", padx=2)
        make_btn(row, "Export", "card", width=80,
                 command=self._export).pack(side="left", padx=2)
        make_btn(row, "Clear", "card", width=80,
                 command=lambda: self._term.clear()).pack(side="left", padx=2)

        self._stats = StatsBar(
            self, ["Files in baseline", "Changed", "Deleted", "New files"]
        )
        self._stats.pack(fill="x", pady=(0, 10))

        self._term = Terminal(self)
        self._term.pack(fill="both", expand=True)

    # ── Helpers ───────────────────────────────────────────────────────────────
    @staticmethod
    def _hash(path: str) -> str:
        h = hashlib.sha256()
        try:
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
            return h.hexdigest()
        except OSError:
            return "UNREADABLE"

    def _snapshot(self, directory: str) -> dict[str, str]:
        result: dict[str, str] = {}
        for root, _, files in os.walk(directory):
            for fname in files:
                full = os.path.join(root, fname)
                rel  = os.path.relpath(full, directory)
                result[rel] = self._hash(full)
        return result

    def _browse(self) -> None:
        d = filedialog.askdirectory(title="Select directory to monitor")
        if d:
            self._watch_dir = d
            self._dir_var.set(d)

    def _start_baseline(self) -> None:
        if not self._watch_dir:
            messagebox.showwarning("No directory", "Select a directory first.")
            return
        threading.Thread(target=self._create_baseline, daemon=True).start()

    def _create_baseline(self) -> None:
        self._term.clear()
        self._term.log(f"Creating baseline for: {self._watch_dir}", "header")
        self._baseline = {}
        for root, _, files in os.walk(self._watch_dir):
            for fname in files:
                full = os.path.join(root, fname)
                rel  = os.path.relpath(full, self._watch_dir)
                h    = self._hash(full)
                self._baseline[rel] = h
                self._term.log(f"  {h[:16]}…  {rel}", "muted")
        with open(self._baseline_file, "w") as f:
            json.dump({"dir": self._watch_dir, "hashes": self._baseline}, f, indent=2)
        n = len(self._baseline)
        self._stats.set("Files in baseline", str(n))
        self._stats.set("Changed",   "0")
        self._stats.set("Deleted",   "0")
        self._stats.set("New files", "0")
        self._term.log(f"Baseline saved — {n} files  →  {self._baseline_file}", "ok")

    def _check(self) -> None:
        if not self._baseline:
            if os.path.exists(self._baseline_file):
                with open(self._baseline_file) as f:
                    data = json.load(f)
                self._baseline  = data.get("hashes", {})
                self._watch_dir = self._watch_dir or data.get("dir")
                self._term.log(
                    f"Loaded baseline from disk ({len(self._baseline)} files).", "info")
            else:
                self._term.log("No baseline found. Create one first.", "warn")
                return

        self._reporter = Reporter("File Integrity Check")
        self._term.log("Checking integrity…", "header")
        current   = self._snapshot(self._watch_dir)
        changed   = 0
        deleted   = 0
        new_files = 0

        for rel, orig in self._baseline.items():
            if rel not in current:
                msg = f"  DELETED   {rel}"
                self._term.log(msg, "danger")
                self._reporter.add(msg)
                deleted += 1
            elif current[rel] != orig:
                msg = f"  CHANGED   {rel}"
                self._term.log(msg, "warn")
                self._reporter.add(msg)
                changed += 1

        for rel in current:
            if rel not in self._baseline:
                msg = f"  NEW FILE  {rel}"
                self._term.log(msg, "info")
                self._reporter.add(msg)
                new_files += 1

        self._stats.set("Changed",   str(changed))
        self._stats.set("Deleted",   str(deleted))
        self._stats.set("New files", str(new_files))
        total_alerts = changed + deleted + new_files

        if total_alerts == 0:
            self._term.log("All files intact ✓", "ok")
        else:
            summary = f"Done — {changed} changed, {deleted} deleted, {new_files} new."
            self._term.log(summary, "warn")
            self._reporter.add(summary)
            if self._dashboard:
                self._dashboard.increment("fim_alerts", total_alerts)

    def _toggle_watch(self) -> None:
        if self._watching:
            self._watching = False
            self._watch_btn.configure(text="Start Watch", fg_color=COLORS["accent"])
            self._term.log("Watch stopped.", "muted")
        else:
            if not self._baseline and not os.path.exists(self._baseline_file):
                messagebox.showwarning("No baseline", "Create a baseline first.")
                return
            self._watching = True
            self._watch_btn.configure(text="Stop Watch", fg_color=COLORS["danger"])
            self._term.log(f"Watching for changes every {self._interval}s…", "ok")
            threading.Thread(target=self._watch_loop, daemon=True).start()

    def _watch_loop(self) -> None:
        while self._watching:
            self._check()
            for _ in range(self._interval * 10):
                if not self._watching:
                    return
                time.sleep(0.1)

    def _export(self) -> None:
        if not self._reporter:
            messagebox.showwarning("Nothing to export", "Run a check first.")
            return
        path = self._reporter.save()
        messagebox.showinfo("Report saved", f"Saved to:\n{path}")
