"""
modules/dashboard.py — Home screen with project overview and quick-start tips.

Shows:
  • Live session stats (updated by other modules via update())
  • Feature cards linking to each module
  • Version + ethical use reminder
"""

import customtkinter as ctk
import tkinter as tk
from datetime import datetime

from utils.theme import COLORS, FONT_LABEL, FONT_TITLE, FONT_HEAD, FONT_SMALL

VERSION = "1.0.0"


class Dashboard(ctk.CTkFrame):
    def __init__(self, master, switch_tab_cb=None) -> None:
        """
        Args:
            switch_tab_cb: callable(key: str) — called when a quick-launch
                           card is clicked, so the sidebar can switch tabs.
        """
        super().__init__(master, fg_color="transparent")
        self._switch = switch_tab_cb
        self._stats: dict[str, tk.StringVar] = {}
        self._session_start = datetime.now()
        self._build()

    # ── Layout ────────────────────────────────────────────────────────────────
    def _build(self) -> None:
        # ── Hero ──────────────────────────────────────────────────────────────
        hero = ctk.CTkFrame(self, fg_color=COLORS["card"], corner_radius=14)
        hero.pack(fill="x", pady=(0, 18))

        left = ctk.CTkFrame(hero, fg_color="transparent")
        left.pack(side="left", fill="both", expand=True, padx=24, pady=20)

        ctk.CTkLabel(left, text="🛡  SecSuite",
                     font=("Segoe UI", 28, "bold"),
                     text_color=COLORS["accent"]).pack(anchor="w")
        ctk.CTkLabel(left, text="Defensive Security Suite",
                     font=("Segoe UI", 14),
                     text_color=COLORS["text"]).pack(anchor="w", pady=(2, 6))
        ctk.CTkLabel(left,
            text="A hands-on toolkit for log analysis, network scanning, "
                 "brute-force detection, and file integrity monitoring.\n"
                 "Built for learning, portfolio, and real-world defensive practice.",
            font=FONT_LABEL, text_color=COLORS["muted"],
            wraplength=520, justify="left",
        ).pack(anchor="w")

        right = ctk.CTkFrame(hero, fg_color="transparent")
        right.pack(side="right", padx=24, pady=20)
        ctk.CTkLabel(right, text=f"v{VERSION}",
                     font=("Segoe UI", 11), text_color=COLORS["muted"]).pack()
        ctk.CTkLabel(right,
            text=datetime.now().strftime("%d %b %Y"),
            font=("Segoe UI", 11), text_color=COLORS["muted"],
        ).pack()

        # ── Session stats ─────────────────────────────────────────────────────
        ctk.CTkLabel(self, text="  SESSION",
                     font=("Segoe UI", 9, "bold"),
                     text_color=COLORS["muted"]).pack(anchor="w", pady=(0, 6))

        stats_row = ctk.CTkFrame(self, fg_color="transparent")
        stats_row.pack(fill="x", pady=(0, 18))

        stat_defs = [
            ("log_hits",    "Log matches",      COLORS["warning"]),
            ("ports_open",  "Open ports found", COLORS["accent"]),
            ("ips_blocked", "IPs blocked",      COLORS["danger"]),
            ("fim_alerts",  "Integrity alerts", COLORS["warning"]),
        ]
        for key, label, color in stat_defs:
            v = tk.StringVar(value="0")
            self._stats[key] = v
            card = ctk.CTkFrame(stats_row, fg_color=COLORS["card"], corner_radius=10)
            card.pack(side="left", expand=True, fill="x", padx=6)
            ctk.CTkLabel(card, textvariable=v,
                         font=("Segoe UI", 26, "bold"),
                         text_color=color).pack(pady=(12, 0))
            ctk.CTkLabel(card, text=label,
                         font=FONT_SMALL,
                         text_color=COLORS["muted"]).pack(pady=(0, 12))

        # ── Module cards ──────────────────────────────────────────────────────
        ctk.CTkLabel(self, text="  MODULES",
                     font=("Segoe UI", 9, "bold"),
                     text_color=COLORS["muted"]).pack(anchor="w", pady=(0, 6))

        grid = ctk.CTkFrame(self, fg_color="transparent")
        grid.pack(fill="x", pady=(0, 18))
        grid.columnconfigure((0, 1), weight=1)

        modules = [
            ("log",   "📋", "Log Analyser",
             "Scan syslog, auth.log, Apache or Nginx logs for SSH failures, "
             "SQL injection, XSS, and brute-force patterns."),
            ("port",  "🔍", "Port Scanner",
             "TCP-scan any host for open ports. Identifies services and flags "
             "risky ports like RDP, SMB, and Telnet."),
            ("brute", "🛡", "Brute-Force Detector",
             "Tracks failed logins per IP in a rolling window and auto-blocks "
             "offending addresses when the threshold is hit."),
            ("fim",   "🔒", "File Integrity Monitor",
             "SHA-256-hashes a directory into a baseline, then watches for "
             "any changes, deletions, or suspicious new files."),
        ]
        for i, (key, icon, title, desc) in enumerate(modules):
            row, col = divmod(i, 2)
            card = ctk.CTkFrame(grid, fg_color=COLORS["card"], corner_radius=12,
                                cursor="hand2")
            card.grid(row=row, column=col, padx=6, pady=6, sticky="nsew")
            card.bind("<Button-1>", lambda e, k=key: self._launch(k))

            inner = ctk.CTkFrame(card, fg_color="transparent")
            inner.pack(fill="both", expand=True, padx=16, pady=14)
            inner.bind("<Button-1>", lambda e, k=key: self._launch(k))

            ctk.CTkLabel(inner, text=f"{icon}  {title}",
                         font=FONT_HEAD, text_color=COLORS["text"],
                         cursor="hand2").pack(anchor="w")
            ctk.CTkLabel(inner, text=desc, font=FONT_SMALL,
                         text_color=COLORS["muted"],
                         wraplength=320, justify="left",
                         cursor="hand2").pack(anchor="w", pady=(6, 0))
            launch = ctk.CTkButton(inner, text="Open →", width=80, height=26,
                                   font=("Segoe UI", 11),
                                   fg_color=COLORS["accent"],
                                   command=lambda k=key: self._launch(k))
            launch.pack(anchor="e", pady=(10, 0))

        # ── Ethics reminder ───────────────────────────────────────────────────
        warn = ctk.CTkFrame(self, fg_color="#1c1208", corner_radius=10)
        warn.pack(fill="x")
        ctk.CTkLabel(warn,
            text="⚠  Only use active tools (port scanner) on hosts you own "
                 "or have explicit written permission to test. "
                 "Unauthorised scanning is illegal in most jurisdictions.",
            font=FONT_SMALL, text_color="#f59e0b",
            wraplength=780, justify="left",
        ).pack(padx=16, pady=10)

    # ── Public ────────────────────────────────────────────────────────────────
    def increment(self, key: str, by: int = 1) -> None:
        """Increment a session counter (call from other modules)."""
        if key in self._stats:
            current = int(self._stats[key].get())
            self._stats[key].set(str(current + by))

    # ── Internal ──────────────────────────────────────────────────────────────
    def _launch(self, key: str) -> None:
        if self._switch:
            self._switch(key)
