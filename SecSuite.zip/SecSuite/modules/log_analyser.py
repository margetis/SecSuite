"""
modules/log_analyser.py — Scan plain-text log files for attack signatures.

Detects:
    • Failed SSH / authentication failures
    • Root login attempts
    • Port-scan hints (invalid user / connection refused)
    • SQL injection patterns
    • XSS patterns
    • Brute-force burst patterns
"""

import re
import os
import threading
from tkinter import filedialog, messagebox
import customtkinter as ctk
import tkinter as tk

from utils.theme    import COLORS, FONT_LABEL, FONT_TITLE
from utils.widgets  import Terminal, StatsBar, make_btn
from utils.reporter import Reporter

PATTERNS: dict[str, tuple[str, str]] = {
    "Failed SSH login":   (r"Failed password|authentication failure",    "warn"),
    "Root login attempt": (r"login.*root|sudo.*root",                    "danger"),
    "Port scan hint":     (r"Invalid user|connection refused",           "warn"),
    "SQL injection":      (r"(?i)(select|union|insert|drop)\s+",         "danger"),
    "XSS attempt":        (r"(?i)<script|javascript:|onerror=",          "danger"),
    "Brute-force burst":  (r"(Failed|Invalid).*(\b\d+\b.*){3,}",        "danger"),
}


class LogAnalyser(ctk.CTkFrame):
    def __init__(self, master, dashboard=None) -> None:
        super().__init__(master, fg_color="transparent")
        self._filepath: str | None = None
        self._dashboard = dashboard
        self._reporter: Reporter | None = None
        self._build()

    def _build(self) -> None:
        ctk.CTkLabel(self, text="📋  Log Analyser", font=FONT_TITLE,
                     text_color=COLORS["accent"]).pack(anchor="w", pady=(0, 4))
        ctk.CTkLabel(self,
            text="Load any plain-text log file (syslog, Apache, Nginx, auth.log …) "
                 "and scan for known attack signatures.",
            font=FONT_LABEL, text_color=COLORS["muted"], wraplength=740,
        ).pack(anchor="w", pady=(0, 12))

        row = ctk.CTkFrame(self, fg_color="transparent")
        row.pack(fill="x", pady=(0, 8))
        self._path_var = tk.StringVar(value="No file selected")
        ctk.CTkLabel(row, textvariable=self._path_var,
                     font=FONT_LABEL, text_color=COLORS["muted"]).pack(side="left", padx=(0, 10))
        make_btn(row, "Browse…", "card",   command=self._browse).pack(side="left", padx=2)
        make_btn(row, "Analyse", "accent", command=self._run).pack(side="left", padx=2)
        make_btn(row, "Export",  "card",   width=80,
                 command=self._export).pack(side="left", padx=2)
        make_btn(row, "Clear",   "card",   width=80,
                 command=lambda: self._term.clear()).pack(side="left", padx=2)

        self._stats = StatsBar(self, ["Lines scanned", "Matches found", "Critical hits"])
        self._stats.pack(fill="x", pady=(0, 10))

        self._term = Terminal(self)
        self._term.pack(fill="both", expand=True)

    def _browse(self) -> None:
        p = filedialog.askopenfilename(
            title="Select log file",
            filetypes=[("Log / text files", "*.log *.txt *"), ("All files", "*.*")],
        )
        if p:
            self._filepath = p
            self._path_var.set(os.path.basename(p))

    def _run(self) -> None:
        if not self._filepath:
            messagebox.showwarning("No file", "Please select a log file first.")
            return
        threading.Thread(target=self._analyse, daemon=True).start()

    def _analyse(self) -> None:
        self._term.clear()
        self._reporter = Reporter("Log Analyser")
        self._term.log(f"Opening: {self._filepath}", "header")
        self._reporter.add(f"File: {self._filepath}")

        try:
            with open(self._filepath, "r", errors="replace") as fh:
                lines = fh.readlines()
        except OSError as e:
            self._term.log(f"Error reading file: {e}", "danger")
            return

        total, matches, critical = len(lines), 0, 0

        for i, line in enumerate(lines, 1):
            for name, (pattern, severity) in PATTERNS.items():
                if re.search(pattern, line):
                    matches += 1
                    if severity == "danger":
                        critical += 1
                    preview = line.strip()[:120]
                    msg = f"[Line {i:>5}]  {name}  —  {preview}"
                    self._term.log(msg, severity)
                    self._reporter.add(msg)

        self._stats.set("Lines scanned", str(total))
        self._stats.set("Matches found", str(matches))
        self._stats.set("Critical hits", str(critical))
        summary = (f"Scan complete — {total} lines scanned, "
                   f"{matches} matches ({critical} critical).")
        self._term.log(summary, "ok")
        self._reporter.add(summary)

        if self._dashboard:
            self._dashboard.increment("log_hits", matches)

    def _export(self) -> None:
        if not self._reporter:
            messagebox.showwarning("Nothing to export",
                                   "Run an analysis first.")
            return
        path = self._reporter.save()
        messagebox.showinfo("Report saved", f"Saved to:\n{path}")
