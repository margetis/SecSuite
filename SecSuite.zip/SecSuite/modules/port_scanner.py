"""
modules/port_scanner.py — TCP port scanner with service identification.

Only use against hosts you own or have explicit permission to test.
"""

import socket
import threading
import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox

from utils.theme    import COLORS, FONT_LABEL, FONT_TITLE
from utils.widgets  import Terminal, StatsBar, make_btn
from utils.config   import get
from utils.reporter import Reporter

SERVICES: dict[int, str] = {
    21: "FTP",       22: "SSH",        23: "Telnet",    25: "SMTP",
    53: "DNS",       80: "HTTP",       110: "POP3",     135: "MS-RPC",
    139: "NetBIOS",  143: "IMAP",      443: "HTTPS",    445: "SMB",
    3306: "MySQL",   3389: "RDP",      5432: "Postgres",
    5900: "VNC",     6379: "Redis",    8080: "HTTP-Alt",
    8443: "HTTPS-Alt", 27017: "MongoDB",
}
RISKY: set[int] = {23, 135, 139, 445, 3389, 5900}


class PortScanner(ctk.CTkFrame):
    def __init__(self, master, dashboard=None) -> None:
        super().__init__(master, fg_color="transparent")
        self._scanning  = False
        self._dashboard = dashboard
        self._reporter: Reporter | None = None
        self._build()

    def _build(self) -> None:
        ctk.CTkLabel(self, text="🔍  Port Scanner", font=FONT_TITLE,
                     text_color=COLORS["accent"]).pack(anchor="w", pady=(0, 4))
        ctk.CTkLabel(self,
            text="Scan a host for open TCP ports. "
                 "Only use on hosts you own or have permission to test.",
            font=FONT_LABEL, text_color=COLORS["muted"], wraplength=740,
        ).pack(anchor="w", pady=(0, 12))

        row = ctk.CTkFrame(self, fg_color="transparent")
        row.pack(fill="x", pady=(0, 6))

        def lbl(text: str) -> ctk.CTkLabel:
            return ctk.CTkLabel(row, text=text, font=FONT_LABEL)

        lbl("Host:").pack(side="left", padx=(0, 4))
        self._host   = tk.StringVar(value=str(get("port_scanner", "default_host")))
        ctk.CTkEntry(row, textvariable=self._host, width=160).pack(side="left", padx=4)

        lbl("Ports:").pack(side="left", padx=(12, 4))
        self._p_from = tk.StringVar(value=str(get("port_scanner", "default_port_from")))
        self._p_to   = tk.StringVar(value=str(get("port_scanner", "default_port_to")))
        ctk.CTkEntry(row, textvariable=self._p_from, width=65).pack(side="left")
        lbl("→").pack(side="left", padx=4)
        ctk.CTkEntry(row, textvariable=self._p_to,   width=65).pack(side="left", padx=4)

        lbl("Timeout (s):").pack(side="left", padx=(12, 4))
        self._timeout = tk.StringVar(value=str(get("port_scanner", "default_timeout")))
        ctk.CTkEntry(row, textvariable=self._timeout, width=55).pack(side="left", padx=4)

        self._scan_btn = make_btn(row, "Scan", "accent", command=self._toggle_scan)
        self._scan_btn.pack(side="left", padx=(12, 4))
        make_btn(row, "Export", "card", width=80,
                 command=self._export).pack(side="left", padx=2)
        make_btn(row, "Clear", "card", width=80,
                 command=lambda: self._term.clear()).pack(side="left", padx=2)

        self._progress = ctk.CTkProgressBar(self, mode="indeterminate", height=5)
        self._progress.pack(fill="x", pady=(4, 8))

        self._stats = StatsBar(self, ["Open ports", "Risky ports", "Closed / filtered"])
        self._stats.pack(fill="x", pady=(0, 10))

        self._term = Terminal(self)
        self._term.pack(fill="both", expand=True)

    def _toggle_scan(self) -> None:
        if self._scanning:
            self._scanning = False
            self._scan_btn.configure(text="Scan", fg_color=COLORS["accent"])
        else:
            threading.Thread(target=self._scan, daemon=True).start()

    def _scan(self) -> None:
        self._scanning = True
        self._scan_btn.configure(text="Stop", fg_color=COLORS["danger"])
        self._progress.start()
        self._term.clear()
        self._stats.reset()
        self._reporter = Reporter("Port Scan")

        host    = self._host.get().strip()
        p_from  = int(self._p_from.get())
        p_to    = int(self._p_to.get())
        timeout = float(self._timeout.get())

        try:
            ip = socket.gethostbyname(host)
        except socket.gaierror as e:
            self._term.log(f"Cannot resolve '{host}': {e}", "danger")
            self._finish()
            return

        header = (f"Scanning {host} ({ip})  —  ports {p_from}–{p_to}  "
                  f"(timeout {timeout}s per port)")
        self._term.log(header, "header")
        self._reporter.add(header)

        open_ports:  list[int] = []
        risky_ports: list[int] = []
        closed = 0

        for port in range(p_from, p_to + 1):
            if not self._scanning:
                self._term.log("Scan stopped by user.", "warn")
                break
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.settimeout(timeout)
                    if s.connect_ex((ip, port)) == 0:
                        service = SERVICES.get(port, "unknown")
                        open_ports.append(port)
                        if port in RISKY:
                            risky_ports.append(port)
                            msg = f"  OPEN  {port:>5}  {service:<14}  ⚠  RISKY"
                            self._term.log(msg, "danger")
                        else:
                            msg = f"  OPEN  {port:>5}  {service}"
                            self._term.log(msg, "ok")
                        self._reporter.add(msg)
                    else:
                        closed += 1
            except Exception:
                closed += 1

        self._stats.set("Open ports",        str(len(open_ports)))
        self._stats.set("Risky ports",       str(len(risky_ports)))
        self._stats.set("Closed / filtered", str(closed))
        summary = (f"Done — {len(open_ports)} open ({len(risky_ports)} risky), "
                   f"{closed} closed/filtered.")
        self._term.log(summary, "ok")
        self._reporter.add(summary)

        if self._dashboard:
            self._dashboard.increment("ports_open", len(open_ports))

        self._finish()

    def _finish(self) -> None:
        self._scanning = False
        self._progress.stop()
        self._progress.set(0)
        self._scan_btn.configure(text="Scan", fg_color=COLORS["accent"])

    def _export(self) -> None:
        if not self._reporter:
            messagebox.showwarning("Nothing to export", "Run a scan first.")
            return
        path = self._reporter.save()
        messagebox.showinfo("Report saved", f"Saved to:\n{path}")
