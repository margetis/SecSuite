<div align="center">

# 🛡 SecSuite

### Defensive Security Suite — Python GUI

![Python](https://img.shields.io/badge/Python-3.11%2B-3b82f6?style=flat-square&logo=python&logoColor=white)
![CustomTkinter](https://img.shields.io/badge/GUI-CustomTkinter-22c55e?style=flat-square)
![License](https://img.shields.io/badge/License-MIT-f59e0b?style=flat-square)
![Platform](https://img.shields.io/badge/Platform-macOS%20%7C%20Windows%20%7C%20Linux-6b7280?style=flat-square)

A hands-on, beginner-friendly Python desktop app covering four core defensive
security disciplines — built for learning and portfolio demonstration.

</div>

---

## ✨ Features

| Module | What it does |
|--------|-------------|
| 📋 **Log Analyser** | Scans syslog / auth.log / Apache / Nginx files for SSH failures, SQL injection, XSS, brute-force bursts, and root login attempts |
| 🔍 **Port Scanner** | TCP-scans any host for open ports, identifies services by port number, and flags risky ports (RDP, SMB, Telnet, VNC…) |
| 🛡 **Brute-Force Detector** | Tracks failed logins per IP in a rolling time window, auto-blocks offending addresses, includes a live simulator |
| 🔒 **File Integrity Monitor** | SHA-256-hashes a directory into a persistent baseline, then monitors for any changes, deletions, or suspicious new files |
| 🏠 **Dashboard** | Live session stats aggregated from all modules |
| ⚙ **Settings** | Configure defaults (ports, thresholds, timeouts, report directory) — saved to `config.json` |
| 📄 **Export Reports** | Save results from any module to a timestamped `.txt` report in the `reports/` folder |

---

## 📁 Project Structure

```
SecSuite/
├── main.py                   ← Entry point
├── app.py                    ← Window, sidebar, tab switcher
├── config.json               ← User-editable defaults
├── requirements.txt
├── LICENSE
│
├── modules/
│   ├── dashboard.py          ← Home screen & session stats
│   ├── log_analyser.py       ← Log file scanner
│   ├── port_scanner.py       ← TCP port scanner
│   ├── brute_force.py        ← Brute-force detector
│   ├── file_integrity.py     ← SHA-256 integrity monitor
│   └── settings.py           ← Settings panel
│
└── utils/
    ├── theme.py              ← Colour palette & fonts
    ├── widgets.py            ← Terminal, StatsBar, make_btn
    ├── config.py             ← Config loader with fallback defaults
    └── reporter.py           ← Report file writer
```

---

## ⚡ Quick Start

**1. Clone the repo**
```bash
git clone https://github.com/alexmargetis/SecSuite.git
cd SecSuite
```

**2. Create a virtual environment and install dependencies**
```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

**3. Run**
```bash
python3 main.py
```

---

## 🔍 Module Guide

### 📋 Log Analyser
1. Click **Browse…** and select any `.log` or `.txt` file
2. Click **Analyse** — matches are printed with line numbers and severity
3. Click **Export** to save a report to `reports/`

Detects: failed SSH, root login attempts, SQL injection, XSS, port scan hints, brute-force bursts.

### 🔍 Port Scanner
1. Enter a target host (IP or hostname)
2. Set a port range (default 1–1024) and timeout
3. Click **Scan** — open ports are listed with service names
4. Risky ports (RDP, SMB, Telnet…) are highlighted in red

> ⚠ Only scan hosts you own or have explicit written permission to test.

### 🛡 Brute-Force Detector
- Configure the threshold (default: 5 attempts) and time window (default: 60s)
- Use the **simulator buttons** to test the logic
- Or call `record_attempt(ip, success)` programmatically from your own log parser
- Blocked IPs are displayed in the red panel and included in the export

### 🔒 File Integrity Monitor
1. Select a directory and click **Create Baseline**
2. The baseline (SHA-256 of every file) is saved to `fim_baseline.json`
3. Click **Check Now** or **Start Watch** (checks every 15s automatically)
4. Any `CHANGED`, `DELETED`, or `NEW FILE` is reported immediately

---

## ⚙️ Configuration

Edit `config.json` directly or use the **Settings** panel inside the app:

```json
{
  "port_scanner":   { "default_host": "127.0.0.1", "default_port_to": 1024 },
  "brute_force":    { "default_threshold": 5, "default_window_s": 60 },
  "file_integrity": { "watch_interval_s": 15 },
  "reports":        { "output_dir": "reports" }
}
```

---

## 🧩 Extending SecSuite

Each module is fully self-contained. To add a new tool:

1. Create `modules/my_tool.py` — extend `ctk.CTkFrame`
2. Import it in `app.py`
3. Add one nav entry in `App._build()`

The shared `Terminal`, `StatsBar`, and `Reporter` helpers keep everything consistent.

---

## ⚠️ Legal & Ethical Use

This tool is built for **defensive** and **educational** purposes only.
Only use the port scanner and other active tools against systems you own
or have explicit written permission to test.
Unauthorised scanning is illegal in most jurisdictions.

---

## 📄 License

MIT — see [LICENSE](LICENSE)
